package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bean.DemandDraft;
import com.capgemini.util.DBUtil;

public class DemandDraftDAO implements IDemandDraftDAO {
	Connection con;

	public int generateTransactionId(){
		int TransactionId=0;
		String SQL="select transaction_id_seq.nextval from dual";
		con=DBUtil.getConnection();
		try {
			Statement statement=con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			TransactionId=resultSet.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Problem accoured while generating Transaction ID"+e.getMessage());
		}
		return TransactionId;
		
	}

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		// TODO Auto-generated method stub
		int transaction_id=generateTransactionId();
		con=DBUtil.getConnection();
	try{
		PreparedStatement preparedStatement=con.prepareStatement(QueryMapper.INSERTQUERY);
		preparedStatement.setInt(1, transaction_id);
		preparedStatement.setString(2,demandDraft.getCustomer_Name());
		preparedStatement.setString(3,demandDraft.getIn_Favour_Name());
		preparedStatement.setString(4,demandDraft.getPhone_number());
		preparedStatement.setFloat(5,demandDraft.getDd_Number());
		preparedStatement.setFloat(6,demandDraft.getDd_commission());
		preparedStatement.setString(7,demandDraft.getDd_description());
		preparedStatement.executeUpdate();
	}catch(SQLException e){
		e.printStackTrace();
	}
	
		return transaction_id ;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		con=DBUtil.getConnection();
		DemandDraft dd = new DemandDraft();
		PreparedStatement preparedStatement;
		try {
			preparedStatement = con.prepareStatement(QueryMapper.SEARCHQUERY);
			preparedStatement.setInt(1, transactionId);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				dd.setTransaction_id(resultSet.getInt("transaction_id"));
				dd.setCustomer_Name(resultSet.getString("customer_Name"));
				dd.setIn_Favour_Name(resultSet.getString("in_Favor_of"));
				dd.setPhone_number(resultSet.getString("phone_number"));
				dd.setDd_Number(resultSet.getFloat("dd_amount"));
				dd.setDd_commission(resultSet.getFloat("dd_commission"));
				dd.setDd_description(resultSet.getString("dd_description"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dd;
	}
	
			
}


