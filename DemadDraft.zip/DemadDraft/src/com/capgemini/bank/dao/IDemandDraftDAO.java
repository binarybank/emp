package com.capgemini.bank.dao;

import com.capgemini.bean.DemandDraft;

public interface IDemandDraftDAO {
	int addDemandDraftDetails(DemandDraft deamandDraft);
	DemandDraft getDemandDraftDetails(int transactionId);
}
