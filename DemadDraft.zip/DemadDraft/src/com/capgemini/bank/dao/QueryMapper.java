package com.capgemini.bank.dao;

public class QueryMapper {
	public static final String INSERTQUERY="insert into demand_draft values(?,?,?,?,sysdate,?,?,?)";
	public static final String SEARCHQUERY="select * from demand_draft where transaction_Id=?";
}
