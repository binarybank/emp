package com.capgemini.bank.service;

import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bean.DemandDraft;

public class DemandDraftService implements IDemandDraftService {
IDemandDraftDAO dao=new DemandDraftDAO();

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		// TODO Auto-generated method stub
		return dao.addDemandDraftDetails(demandDraft);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		// TODO Auto-generated method stub
		return dao.getDemandDraftDetails(transactionId);
	}

}
