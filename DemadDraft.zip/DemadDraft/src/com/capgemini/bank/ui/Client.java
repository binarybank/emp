package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bean.DemandDraft;

public class Client {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		IDemandDraftService Dand= new DemandDraftService();
		do{
			System.out.println("****************************");
			System.out.println("1.Enter DemandDraftDetails");
			System.out.println("2.Print Demand Draft");
			System.out.println("3.Exit");
			System.out.println("enter your choice");
			System.out.println("****************************");
			int choice =sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("enter the name");
				String name=sc.next();
				System.out.println("enter in_favour of");
				String favour=sc.next();
				System.out.println("enter the phone number");
				String number=sc.next();
				System.out.println("amount");
				float amount=sc.nextFloat();
				System.out.println(" enter the Description");
				String desc=sc.next();
				float commission = 0;
				if(amount<=5000){
					commission=10;
					amount=amount+commission;
					
				}else if(amount>=5001 && amount<=10000){
					commission=41;
					amount=amount+commission;					
					
				}else if(amount>=10001 && amount<=100000){
					commission=51;
					amount=amount+commission;
					
				}else if(amount>=100001 && amount<=500000){
					commission=306;
					amount=amount+commission;
				}	
				DemandDraft d=new DemandDraft(0, name, favour, number, amount, commission, desc);
				Dand.addDemandDraftDetails(d);
				System.out.println("values has been entered");
				break;
			case 2:
				System.out.println("enter the transactionId");
	            int transaction_id_seq = sc.nextInt();
	            DemandDraft dd1=Dand.getDemandDraftDetails(transaction_id_seq);
	            System.out.println(dd1);
	            break;
			    
			case 3:
				
				System.exit(0);
			    default:System.out.println("Invalid choice try again");
				

	
				break;
			}
			
		}while(true);
		
	}

}
