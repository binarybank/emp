package com.capgemini.bean;

public class DemandDraft {
	private int Transaction_id;
	private String Customer_Name;
	private String In_Favour_Name;
	private String Phone_number;
	private float dd_Number;
	private float dd_commission;
	private String dd_description;
	public DemandDraft(){
		
	}
	
	
	
	public DemandDraft(int transaction_id, String customer_Name,
			String in_Favour_Name, String phone_number, float dd_Number,
			float dd_commission, String dd_description) {
		this.Transaction_id = transaction_id;
		this.Customer_Name = customer_Name;
		this.In_Favour_Name = in_Favour_Name;
		this.Phone_number = phone_number;
		this.dd_Number = dd_Number;
		this.dd_commission = dd_commission;
		this.dd_description = dd_description;
	}
	public int getTransaction_id() {
		return Transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.Transaction_id = transaction_id;
	}
	public String getCustomer_Name() {
		return Customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		this.Customer_Name = customer_Name;
	}
	public String getIn_Favour_Name() {
		return In_Favour_Name;
	}
	public void setIn_Favour_Name(String in_Favour_Name) {
		this.In_Favour_Name = in_Favour_Name;
	}
	public String getPhone_number() {
		return Phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.Phone_number = phone_number;
	}
	public float getDd_Number() {
		return dd_Number;
	}
	public void setDd_Number(float dd_Number) {
		this.dd_Number = dd_Number;
	}
	public float getDd_commission() {
		return dd_commission;
	}
	public void setDd_commission(float dd_commission) {
		this.dd_commission = dd_commission;
	}
	public String getDd_description() {
		return dd_description;
	}
	public void setDd_description(String dd_description) {
		this.dd_description = dd_description;
	}
	@Override
	public String toString() {
		return "DemandDraft [Transaction_id=" + Transaction_id
				+ ", Customer_Name=" + Customer_Name + ", In_Favour_Name="
				+ In_Favour_Name + ", Phone_number=" + Phone_number
				+ ", dd_Number=" + dd_Number + ", dd_commission="
				+ dd_commission + ", dd_description=" + dd_description + "]";
	}
}
