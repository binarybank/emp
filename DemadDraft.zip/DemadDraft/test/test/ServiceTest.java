import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

import com.capgemini.bank.service.CustomerValidator;


public class ServiceTest {

	@Test
	public void test() {
			CustomerValidator validator = new CustomerValidator();
			boolean actual = validator.validateName("krishna");
			boolean expected = false;
			Assert.assertEquals(expected, actual);
		}
		
	}


