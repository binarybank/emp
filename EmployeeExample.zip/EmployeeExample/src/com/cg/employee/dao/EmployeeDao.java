package com.cg.employee.dao;

import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeDao {
	
	public int addEmployee(Employee obj)throws EmployeeException;
	public ArrayList<Employee>getAllEmployee()throws EmployeeException;
	public Employee getEmployeeById(int empId)throws EmployeeException;

}
