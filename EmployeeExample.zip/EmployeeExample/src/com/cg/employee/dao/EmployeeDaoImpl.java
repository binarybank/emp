package com.cg.employee.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao{

	Connection con;
	
	public EmployeeDaoImpl()
	{
		con = DBUtil.getConnect();
	}
	@Override
	public int addEmployee(Employee obj)throws EmployeeException{
		// TODO Auto-generated method stub
		int eid = 0;
		try
		{
			String query = "INSERT INTO CRMPune VALUES(eId_CRM.NEXTVAL,?,?,?)";
			PreparedStatement pstmt = 
					con.prepareStatement(query);
			pstmt.setString(1, obj.getEmpName());
			pstmt.setInt(2, obj.getEmpSal());
			java.sql.Date date = Date.valueOf(obj.getBdate());
			pstmt.setDate(3, date);
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				eid = getEmployeeId();
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return eid;
	}
	public int getEmployeeId()throws EmployeeException
	{
		int id = 0;
		String qry = "SELECT eid_CRM.CURRVAL FROM DUAL";
		try
		{
			Statement stmt = 
					con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return id;
	}
	@Override
	public ArrayList<Employee> getAllEmployee()throws EmployeeException {
		// TODO Auto-generated method stub
		ArrayList<Employee>list = new ArrayList<Employee>();
		String qry = "SELECT * FROM CRMPune";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int salary = rs.getInt(3);
				LocalDate date = rs.getDate(4).toLocalDate();
				Employee emp =
						new Employee(id,name,salary,date);
				list.add(emp);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return list;
	}

	@Override
	public Employee getEmployeeById(int empId)throws EmployeeException {
		// TODO Auto-generated method stub
		Employee emp = null;
		String qry = "SELECT * FROM CRMPune WHERE empId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, empId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int salary = rs.getInt(3);
				LocalDate date = rs.getDate(4).toLocalDate();
				emp = new Employee(id,name,salary,date);
			}
			
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return emp;
	}

}
