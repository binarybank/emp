package com.cg.employee.service;

import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeService {

	public int addEmployee(Employee obj)throws EmployeeException;
	public Employee getEmployeeById(int empId)throws EmployeeException;
	public ArrayList<Employee>getAllEmployee()throws EmployeeException;
	public boolean validateName(String name);
	public boolean validateSalary(int salary);
	public boolean validateId(int empId);
	
}




