package com.cg.employee.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao;
	
	public EmployeeServiceImpl()
	{
		dao = new EmployeeDaoImpl();
	}
	@Override
	public int addEmployee(Employee obj) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.addEmployee(obj);
	}

	@Override
	public Employee getEmployeeById(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployeeById(empId);
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getAllEmployee();
	}

	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		String pattern = "[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,name))
		return true;
		else
			return false;
	}

	@Override
	public boolean validateSalary(int salary) {
		// TODO Auto-generated method stub
		String pattern = "[0-9]{4,6}";
		if(Pattern.matches(pattern,salary+""))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateId(int empId) {
		// TODO Auto-generated method stub
		String pattern = "[0-9]{3}";
		if(Pattern.matches(pattern,empId+""))
			return true;
		else			
		return false;
	}

	
	

}
