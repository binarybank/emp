package com.capgemini.tcc.bean;

import java.sql.Date;

public class PatientBean {
private int PatientId;
private String patientName;
private int age;
private int phone;
private String description;
private Date ConsultantDate;
public PatientBean(){
	
}
public void display(){
	System.out.println("Name of the Patient: "+patientName);
	System.out.println("Age: "+age);
	System.out.println("Phone Number: "+phone);
	System.out.println("Description: "+description);
	System.out.println("Consultation Date: "+ConsultantDate);
}
public PatientBean(int patientId, String patientName, int age, int phone, String description) {
	super();
	PatientId = patientId;
	this.patientName = patientName;
	this.age = age;
	this.phone = phone;
	this.description = description;
}
public PatientBean(int patientId, String patientName, int age, int phone, String description, Date consultantDate) {
	super();
	PatientId = patientId;
	this.patientName = patientName;
	this.age = age;
	this.phone = phone;
	this.description = description;
	ConsultantDate = consultantDate;
}
public int getPatientId() {
	return PatientId;
}
public void setPatientId(int patientId) {
	PatientId = patientId;
}
public String getPatientName() {
	return patientName;
}
public void setPatientName(String patientName) {
	this.patientName = patientName;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public int getPhone() {
	return phone;
}
public void setPhone(int phone) {
	this.phone = phone;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public Date getConsultantDate() {
	return ConsultantDate;
}
public void setConsultantDate(Date consultantDate) {
	ConsultantDate = consultantDate;
}
@Override
public String toString() {
	return "PatientBean [PatientId=" + PatientId + ", patientName=" + patientName + ", age=" + age + ", phone=" + phone
			+ ", description=" + description + ", ConsultantDate=" + ConsultantDate + "]";
}

}