package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.util.DBUtil;

public class PatientDAO implements IPatientDAO {
	Connection con;
	
	public int generatePatientId() throws PatientException{
		int generatePatientId=0;
		String SQ="select Patient_id_seq.nextval from dual";
		con=DBUtil.getConnection();
		try {
			Statement statement=con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQ);
			resultSet.next();
			generatePatientId=resultSet.getInt(1);
		} catch (SQLException e) {
			System.out.println("Problem accoured while generating Transaction ID"+e.getMessage());
		}
		return generatePatientId;
	}
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		String sql="INSERT INTO patient values(?,?,?,?,?,sysdate)";
		patient.setPatientId(generatePatientId());
		
		con =DBUtil.getConnection();
		try{
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, patient.getPatientId());
			pst.setString(2, patient.getPatientName());
			pst.setInt(3, patient.getAge());
			pst.setInt(4, patient.getPhone());
			pst.setString(5, patient.getDescription());
			pst.executeUpdate();
		}catch(SQLException e){
			throw new PatientException("Problem in inserting order details"+e);
		}		return patient.getPatientId();
	}

	@Override
	public PatientBean getPatientDetails(int patientId) {
		con=DBUtil.getConnection();
		PatientBean patient=new PatientBean();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(com.capgemini.tcc.querymapper.QueryMapper.SEARCHQUERY);
			preparedStatement.setLong(1, patientId);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				patient.setPatientId(resultSet.getInt(1));
				patient.setPatientName(resultSet.getString(2));
				patient.setAge(resultSet.getInt(3));
				patient.setPhone(resultSet.getInt(4));
				patient.setDescription(resultSet.getString(5));
				patient.setConsultantDate(resultSet.getDate(6));;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		return patient;
	}

}
