package com.capgemini.tcc.querymapper;

public class QueryMapper {
	public static final String SEARCHQUERY="select * from Patient where PATIENT_ID=?";
}
