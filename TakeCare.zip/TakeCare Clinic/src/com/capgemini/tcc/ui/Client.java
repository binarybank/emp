package com.capgemini.tcc.ui;

import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {
public static void main(String[] args) {
	do {
		System.out.println("---------------TakeCare Clinic---------------");
		System.out.println("1.Add Patient Information");
		System.out.println("2.Search Patient by Id");
		System.out.println("3.Exit");
		IPatientService pser=new PatientService();
		Scanner sc=new Scanner(System.in);
		int option=sc.nextInt();
		switch(option){
		case 1:
			System.out.println("enter the name of Patient:");
			String name=sc.next();
			System.out.println("enter the age:");
			int age=sc.nextInt();
			System.out.println("enter the phone number:");
			int phone=sc.nextInt();
			System.out.println("enter the description:");
			String desc=sc.next();
			PatientBean patient=new PatientBean(0, name, age, phone, desc);
			try {
				pser.addPatientDetails(patient);
			} catch (PatientException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:
			System.out.println("enter the PatientID to get details");
			int patientId=sc.nextInt();
			PatientBean pb=pser.getPatientDetails(patientId);
			pb.display();
			break;
		case 3:
			System.out.println("LogOut");
			System.exit(0);
			break;

			default:
				System.out.println("You have entered other than the option.");
				break;
		}
		
			
	}while(true);
}
}
