package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.frs.Util.DBUtil;
import com.cg.frs.dto.FlatOwner;
import com.cg.frs.dto.FlatRegistrations;

public class FlatRegistrationDaoImpl implements IFlatRegistrationDAO {
	private static final int Owner_Id = 0;
	Connection con;
	public long generateFlat_Reg_no(){
		long Flat_Reg_no=0;
		String SQL="select  flat_seqs.nextval from dual";
		con= DBUtil.getConnection();
		try {
			Statement statement=con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			Flat_Reg_no=resultSet.getLong(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Problem accoured while generating Flat_Reg_no"+e.getMessage());
		}
		return Flat_Reg_no;
	}
	
	public FlatRegistrations registerFlat(FlatRegistrations flat) {
			// TODO Auto-generated method stub
			long flat_Reg_no=generateFlat_Reg_no();
			con=DBUtil.getConnection();
			try{
				PreparedStatement preparedStatement=con.prepareStatement(QueryMapper.INSERTQUERY);
				preparedStatement.setLong(1, flat_Reg_no);
				preparedStatement.setInt(2,flat.getOwner_Id());
				preparedStatement.setInt(3,flat.getFlat_Type());
				preparedStatement.setInt(4,flat.getFlat_Area());
				preparedStatement.setDouble(5,flat.getRent_Area());
				preparedStatement.setDouble(6,flat.getDeposit_Amount());
				preparedStatement.executeUpdate();
			}catch(SQLException e){
				e.printStackTrace();
			}

			return flat;
	}
		

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		
		ArrayList<Integer> Flatlist=new ArrayList<Integer>();
		con=DBUtil.getConnection();
		try {
			Statement statement=con.createStatement();
			ResultSet resultSet=statement.executeQuery(QueryMapper.SELECTQUERY);
			while(resultSet.next()){
				FlatOwner flatR= new FlatOwner();
				flatR.setOwner_Id(resultSet.getInt(1));
				Flatlist.add(flatR.getOwner_Id());
			}
		}
			catch (SQLException e){
				e.printStackTrace();
			}
				
			
		return Flatlist;
	}

}
