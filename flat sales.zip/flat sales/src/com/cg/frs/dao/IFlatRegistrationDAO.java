package com.cg.frs.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.frs.dto.FlatRegistrations;

public interface IFlatRegistrationDAO {
	public FlatRegistrations registerFlat(FlatRegistrations flat);
	public ArrayList<Integer> getAllOwnerIds();
   
}
