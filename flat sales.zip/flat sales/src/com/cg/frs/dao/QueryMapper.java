package com.cg.frs.dao;

public class QueryMapper {
	public static final String INSERTQUERY="insert into flat_registrations values(?,?,?,?,?,?)";
	public static final String SELECTQUERY="select *from flat_owners";
}
