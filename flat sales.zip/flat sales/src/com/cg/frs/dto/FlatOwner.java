package com.cg.frs.dto;

public class FlatOwner {
	private int Owner_Id;
	private String Owner_Name;
	private long Mobile_Number; 
	public FlatOwner() {
		// TODO Auto-generated constructor stub
	}
	
	public FlatOwner(int owner_Id, String owner_Name, long mobile_Number) {
		super();
		Owner_Id = owner_Id;
		Owner_Name = owner_Name;
		Mobile_Number = mobile_Number;
	}
	@Override
	public String toString() {
		return "FlatOwner [Owner_Id=" + Owner_Id + ", Owner_Name=" + Owner_Name
				+ ", Mobile_Number=" + Mobile_Number + "]";
	}
	public int getOwner_Id() {
		return Owner_Id;
	}
	public void setOwner_Id(int owner_Id) {
		Owner_Id = owner_Id;
	}
	public String getOwner_Name() {
		return Owner_Name;
	}
	public void setOwner_Name(String owner_Name) {
		Owner_Name = owner_Name;
	}
	public long getMobile_Number() {
		return Mobile_Number;
	}
	public void setMobile_Number(long mobile_Number) {
		Mobile_Number = mobile_Number;
	}
	

}
