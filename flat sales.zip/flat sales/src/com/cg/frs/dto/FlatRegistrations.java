package com.cg.frs.dto;

public class FlatRegistrations {
	private long Flat_Reg_no;
	private int Owner_Id;
	//private String Flat_Owners;
	private int Flat_Type;
	private int Flat_Area;
	private double Rent_Area;
	private double Deposit_Amount;
	
	public long getFlat_Reg_no() {
		return Flat_Reg_no;
	}
	public void setFlat_Reg_no(long flat_Reg_no) {
		Flat_Reg_no = flat_Reg_no;
	}
	public int getOwner_Id() {
		return Owner_Id;
	}
	public void setOwner_Id(int owner_Id) {
		Owner_Id = owner_Id;
	}
	
	public int getFlat_Type() {
		return Flat_Type;
	}
	public void setFlat_Type(int flat_Type) {
		Flat_Type = flat_Type;
	}
	public int getFlat_Area() {
		return Flat_Area;
	}
	public void setFlat_Area(int flat_Area) {
		Flat_Area = flat_Area;
	}
	public double getRent_Area() {
		return Rent_Area;
	}
	public void setRent_Area(double rent_Area) {
		Rent_Area = rent_Area;
	}
	public double getDeposit_Amount() {
		return Deposit_Amount;
	}
	public void setDeposit_Amount(double deposit_Amount) {
		Deposit_Amount = deposit_Amount;
	}
	
	public FlatRegistrations(long flat_Reg_no, int owner_Id, int flat_Type, int flat_Area, double rent_Area,
			double deposit_Amount) {
		super();
		Flat_Reg_no = flat_Reg_no;
		Owner_Id = owner_Id;
		
		Flat_Type = flat_Type;
		Flat_Area = flat_Area;
		Rent_Area = rent_Area;
		Deposit_Amount = deposit_Amount;
	}
	public FlatRegistrations() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "FlatRegistrationDTO [Flat_Reg_no=" + Flat_Reg_no
				+ ", Owner_Id=" + Owner_Id + ", Flat_Type=" + Flat_Type + ", Flat_Area=" + Flat_Area
				+ ", Rent_Area=" + Rent_Area + ", Deposit_Amount="
				+ Deposit_Amount + "]";
	}

}
