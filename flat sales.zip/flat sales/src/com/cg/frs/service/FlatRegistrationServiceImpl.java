package com.cg.frs.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.frs.dao.FlatRegistrationDaoImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrations;


public class FlatRegistrationServiceImpl implements IFlatRegistrationService{
	IFlatRegistrationDAO dao=new FlatRegistrationDaoImpl();

	@Override
	public FlatRegistrations registerFlat(FlatRegistrations flat) {
		// TODO Auto-generated method stub
		return dao.registerFlat(flat);
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		// TODO Auto-generated method stub
		return dao.getAllOwnerIds();
	}
	
	
}
