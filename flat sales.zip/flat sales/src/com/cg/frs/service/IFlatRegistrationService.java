package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dto.FlatRegistrations;

public interface IFlatRegistrationService {
	FlatRegistrations registerFlat(FlatRegistrations flat);
	ArrayList<Integer>getAllOwnerIds();

}
