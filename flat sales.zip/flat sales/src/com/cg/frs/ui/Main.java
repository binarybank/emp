package com.cg.frs.ui;

import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrations;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		IFlatRegistrationService FlatI = new FlatRegistrationServiceImpl();
		do{
			System.out.println("****************************");
			System.out.println("1.Register Flat");
			System.out.println("2.Exit");
			System.out.println("enter your choice");
			System.out.println("****************************");
			int choice =sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("existing ower ids are:"+FlatI.getAllOwnerIds());
				long flat = 0;
	            System.out.println("please enter your owner id form above list");
	            int ID=sc.nextInt();
	            System.out.println("1-1BHK,2-2BHK");
	            int FS=sc.nextInt();
	            System.out.println("enter the faltArea");
	            int FA=sc.nextInt();
	            System.out.println("enter RentAmount");
	            Double RA=sc.nextDouble();
	            System.out.println("enter depositedAmount:");
	            Double DA=sc.nextDouble();
	            FlatRegistrations FR= new FlatRegistrations(flat,ID,FS,FA,RA,DA);
	            if(RA>DA){
	             FlatI.registerFlat(FR);
	             System.out.println("hi and uppal bal");
	            }
			}
		}while(true);
	}
}
	
	            	
	          
	            	
	            
		
		
