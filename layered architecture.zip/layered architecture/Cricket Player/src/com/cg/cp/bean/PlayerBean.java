package com.cg.cp.bean;

import java.time.LocalDate;

public class PlayerBean {
	private String playerId;
	private String playerName;
	private String teamName;
	private String role;
	private String birthDate;
	private LocalDate registrationDate;
	public PlayerBean() {
		
	}

	public PlayerBean(String playerId, String playerName, String teamName,
			String role, String birthDate,LocalDate registrationDate) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.teamName = teamName;
		this.role = role;
		this.birthDate = birthDate;
		this.registrationDate=registrationDate;
	}

	public String getPlayerId() {
		return playerId;
	}

	public void setPlayerId(String playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	@Override
	public String toString() {
		return "PlayerBean [playerId=" + playerId + ", playerName="
				+ playerName + ", teamName=" + teamName + ", role=" + role
				+ ", birthDate=" + birthDate + ", registrationDate="
				+ registrationDate + "]";
	}

	
}
