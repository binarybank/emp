package com.cg.cp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.cp.Exception.PlayerException;
import com.cg.cp.Util.DBUtil;
import com.cg.cp.bean.PlayerBean;

public class daoPlayerImpl implements IdaoPlayer {
	Connection conn = null;

	@Override
	public String addNewPlayer(PlayerBean player) throws PlayerException {
		player.setPlayerId(generatePlayerId());
		try {
			conn = DBUtil.getConnection();
			PreparedStatement pst = conn
					.prepareStatement(QueryMapper.INSERT_PLAYER_QUERY);
			pst.setString(1, player.getPlayerId());
			pst.setString(2, player.getPlayerName());
			pst.setString(3, player.getTeamName());
			pst.setString(4, player.getRole());
			pst.setString(5, player.getBirthDate());
			// LocalDate to java.sql.Date
			pst.setDate(6, Date.valueOf(LocalDate.now()));
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new PlayerException("Problem in inserting Player details"
					+ e.getMessage());
		}
		return player.getPlayerId();
	}

	public String generatePlayerId() throws PlayerException {
		String pid = null;
		try {
			conn = DBUtil.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt
					.executeQuery(QueryMapper.PLAYERID_SEQUENCE_QUERY);
			while (rst.next()) {
				pid = rst.getString(1);
			}
		} catch (SQLException e) {
			throw new PlayerException("Problem in generating mobile id");
		}
		return pid;

	}

	@Override
	public List<PlayerBean> getAllplayers() throws PlayerException {
		List<PlayerBean> playerlist = new ArrayList<PlayerBean>();
		try {
			conn = DBUtil.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt
					.executeQuery(QueryMapper.RETRIVE_ALL_PLAYERS_QUERY);
			while (rst.next()) {
				PlayerBean player = new PlayerBean();
				player.setPlayerId(rst.getString("playerid"));
				player.setPlayerName(rst.getString("playername"));
				player.setTeamName(rst.getString("teamname"));
				player.setRole(rst.getString("role"));
				player.setBirthDate(rst.getString("bdate"));
				// sql.Date to LocalDate
				player.setRegistrationDate(rst.getDate("regddate")
						.toLocalDate());
				playerlist.add(player);
			}
		} catch (SQLException e) {
			throw new PlayerException("Problem in fetching player list");
		}

		return playerlist;
	}

	@Override
	public PlayerBean getPlayerDetailbyId(int id) throws PlayerException {
		PlayerBean p;
		try {
			conn = DBUtil.getConnection();
			p = new PlayerBean();
			PreparedStatement pst = conn
					.prepareStatement(QueryMapper.RETRIEVE_PLAYER_BY_ID);
			pst.setInt(1, id);
			ResultSet rst = pst.executeQuery();
			while (rst.next()) {
				p.setPlayerId(rst.getString(1));
				p.setPlayerName(rst.getString(2));
				p.setTeamName(rst.getString(3));
				p.setRole(rst.getString(4));
				p.setBirthDate(rst.getString(5));
				p.setRegistrationDate(rst.getDate(6).toLocalDate());
			}
		} catch (SQLException e) {
			throw new PlayerException("Problem in fetching Player Detail by id"
					+ " " + e.getMessage());
		}

		return p;
	}

}
