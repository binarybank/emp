package com.cg.cp.main;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.cp.Exception.PlayerException;
import com.cg.cp.bean.PlayerBean;
import com.cg.cp.service.CricketPlayerImpl;
import com.cg.cp.service.ICricketPlayer;

public class Main {

	public static void main(String[] args) {
		ICricketPlayer service = new CricketPlayerImpl();
		Scanner scanner = new Scanner(System.in);

		do {
			System.out.println("============================================");
			System.out.println("||              SELECT MENU               ||");
			System.out.println("============================================");
			System.out.println("|       1. Add new player                  |");
			System.out.println("|       2. View All Players                |");
			System.out.println("|       3. View Player by ID               |");
			System.out.println("|       4. EXIT                            |");
			System.out.println("============================================");
			System.out.println("Please Enter your choice\n");
			String choice = scanner.nextLine();

			switch (choice) {
			case "1":
				/*******************************************
				 * -> Case for adding new mobile
				 *******************************************/
				System.out.println("Please enter Player name you want to add");
				String pname = scanner.nextLine();
				System.out.println("Please enter Team name you want to add");
				String tname = scanner.nextLine();
				System.out
						.println("Please enter Role of the player you want to add");
				String rname = scanner.nextLine();
				System.out
						.println("Please enter D.O.B of the player you want to add in the format (dd/MM/yyyy)");
				String bdate = scanner.nextLine();
				PlayerBean player = new PlayerBean(null, pname, tname, rname,
						bdate, null);

				try {
					if (service.isValidNewPlayer(player)) {
						String cid = service.addNewPlayer(player);
						System.out
								.println("Player details inserted successfully in table with id "
										+ cid);
					}
				} catch (PlayerException e) {
					System.out.println(e.getMessage());
				}
				break;
			case "2":
				try {
					List<PlayerBean> plist = service.getAllplayers();
					if (plist.size() == 0) {
						System.err.println("No players available to show");
					} else {
						for (PlayerBean p : plist) {
							System.out.println(p);
						}
					}
				} catch (PlayerException e) {
					System.out.println(e.getMessage());
				}

				break;
			case "3":
				System.out.println("Enter Player id to get the details");
				String pid = scanner.nextLine();
				if (Pattern.matches("[0-9]{4}", pid)) {
					int id = Integer.parseInt(pid);
					PlayerBean p;
					try {
						p = service.getPlayerDetailbyId(id);
						System.out.println("Player ID:" + p.getPlayerId()
								+ "\n" + "PlayerName:" + p.getPlayerName()
								+ "\n" + "TeamName:" + p.getTeamName() + "\n"
								+ "Role:" + p.getRole() + "\n" + "D.O.B:"
								+ p.getBirthDate() + "\n"
								+ "Registration Date:"
								+ p.getRegistrationDate());
					} catch (PlayerException e) {
						System.out.println(e.getMessage());
					}
				} else
					System.err.println("enter Correct Id");

				break;
			case "4":
				System.exit(0);
				break;

			default:
				System.out.println("Enter correct choice");
				break;
			}

		} while (true);

	}

}
