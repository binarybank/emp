package com.cg.cp.service;

import java.util.List;

import com.cg.cp.Exception.PlayerException;
import com.cg.cp.bean.PlayerBean;
import com.cg.cp.dao.IdaoPlayer;
import com.cg.cp.dao.daoPlayerImpl;

public class CricketPlayerImpl implements ICricketPlayer {
	IdaoPlayer dao = new daoPlayerImpl();



	@Override
	public String addNewPlayer(PlayerBean player) throws PlayerException {
		// TODO Auto-generated method stub
		return dao.addNewPlayer(player);
	}

	@Override
	public boolean isValidNewPlayer(PlayerBean player) throws PlayerException {
		
		 if(!player.getPlayerName() .matches("^[a-zA-Z0-9SS]{3,30}$")){
		
			throw new PlayerException("Player name should start with capital letter and it should be minimum of 3 letters");
		}
		return true;
	}

	@Override
	public List<PlayerBean> getAllplayers() throws PlayerException {
		// TODO Auto-generated method stub
		return dao.getAllplayers();
	}

	@Override
	public PlayerBean getPlayerDetailbyId(int id) throws PlayerException {
		// TODO Auto-generated method stub
		return dao.getPlayerDetailbyId(id);
	}

}
