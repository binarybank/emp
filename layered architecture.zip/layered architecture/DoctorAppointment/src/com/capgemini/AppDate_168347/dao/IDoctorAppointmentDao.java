package com.capgemini.doctors.dao;

import java.util.List;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.AppointmentException;

public interface IDoctorAppointmentDao {

	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws AppointmentException;
	List<DoctorAppointment> getAppointmentDetails(int appointmentId) throws AppointmentException;
}
