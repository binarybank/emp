package com.capgemini.AppDate_168347.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.AppointmentException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client {

	public static void main(String[] args) throws com.capgemini.AppDate_168347.exception.AppointmentException {

		Scanner sc = new Scanner(System.in);
		IDoctorAppointmentService rser = new DoctorAppointmentService();
		do{
			System.out.println("Menu");
			System.out.println("1. Book Doctor Appointment ");
			System.out.println("2. View Doctor Appointment ");
			System.out.println("3. Exit ");
			System.out.println("Enter Your Choice : ");
			int choice = sc.nextInt();
			switch(choice){
			
			case 1:
				
					DoctorAppointment docApp = new DoctorAppointment();
					System.out.println("Enter Name of the Patient : ");
					String name = sc.next();
					docApp.setPatienceName(name);
					System.out.println("Enter Phone Number : ");
					String number = sc.next();
					docApp.setPhoneNumber(number);
					System.out.println("Enter Email : ");
					String mail = sc.next();
					docApp.setEmail(mail);
					System.out.println("Enter Age : ");
					int age = sc.nextInt();
					docApp.setAge(age);
					System.out.println("Enter Gender : ");
					String gender = sc.next();
					docApp.setGender(gender);
					System.out.println("Enter Problem Name : ");
					String problem = sc.next();
					docApp.setProblemName(problem);
					rser.addDoctorAppointmentDetails(docApp);
					System.out.println("Enter Date of Appointment : ");
					String appDate = sc.next();
					DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
					LocalDate appointmentDate = LocalDate.parse(appDate, format);
					docApp.setDateOfAppointment(Date.valueOf(appointmentDate));
			case 2:
				try {
					System.out.println("Enter the Appointment Id : ");
					int appoointmentNum = sc.nextInt();
					List<DoctorAppointment> clist = rser.getDoctorAppointmentDetails(appoointmentNum);
					if(clist.size()==0){
						System.out.println("No Appointment Avavilable");
					}
					else {
						System.out.println("Patient_Name \t Appointment_Status \t Doctor_Name \t Appointment_Date in Weeks : ");
						clist.stream().forEach(System.out::println);
					}
					
				} catch (AppointmentException e) {
					
					System.err.println(e.getMessage());
				}
				
				
			}
	}while(true);

	}
}