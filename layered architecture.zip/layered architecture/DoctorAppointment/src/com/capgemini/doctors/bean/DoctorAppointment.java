package com.capgemini.doctors.bean;

import java.sql.Date;
import java.time.LocalDate;

public class DoctorAppointment {

	int appointmentId;
	String patienceName;
	String phoneNumber;
	Date dateOfAppointment;
	String email;
	int age;
	String gender;
	String problemName;
	String doctorName;
	String appointmentStatus;
	
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getPatienceName() {
		return patienceName;
	}
	public void setPatienceName(String patienceName) {
		this.patienceName = patienceName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Date getDateOfAppointment() {
		return dateOfAppointment;
	}
	public void setDateOfAppointment(Date date) {
		this.dateOfAppointment = date;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getProblemName() {
		return problemName;
	}
	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getAppointmentStatus() {
		return appointmentStatus;
	}
	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}
	@Override
	public String toString() {
		return "DoctorAppointment [appointmentId=" + appointmentId
				+ ", patienceName=" + patienceName + ", phoneNumber="
				+ phoneNumber + ", dateOfAppointment=" + dateOfAppointment
				+ ", email=" + email + ", age=" + age + ", gender=" + gender
				+ ", problemName=" + problemName + ", doctorName=" + doctorName
				+ ", appointmentStatus=" + appointmentStatus + "]";
	}
	
	
}
