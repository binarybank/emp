package com.cg.doctors.bean;

import java.time.LocalDate;

public class DoctorAppointment {

	private int appointmentId;
	private String pName;
	private LocalDate date;
	private String problemName;
	private String doctorName;
	private String appointmentStatus;
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appId) {
		this.appointmentId = appId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getProblemName() {
		return problemName;
	}
	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getAppointmentStatus() {
		return appointmentStatus;
	}
	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}
	@Override
	public String toString() {
		return "DoctorAppointment [appId=" + appointmentId + ", pName=" + pName + ", date=" + date + ", problemName="
				+ problemName + ", doctorName=" + doctorName + ", appointmentStatus=" + appointmentStatus + "]";
	}
	
}
