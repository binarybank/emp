package com.cg.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.doctors.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao{

	Map<Integer,DoctorAppointment> appointments=new HashMap<>();
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {

		appointments.put(doctorAppointment.getAppointmentId(),doctorAppointment);
		return doctorAppointment.getAppointmentId();
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId) {
		DoctorAppointment doctorAppointment = appointments.get(appointmentId);
		return doctorAppointment;
	}

}
