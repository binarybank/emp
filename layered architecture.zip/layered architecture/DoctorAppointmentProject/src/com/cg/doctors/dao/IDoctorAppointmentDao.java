package com.cg.doctors.dao;

import com.cg.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentDao {

	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment);

	DoctorAppointment getAppointmentDetails(int appointmentId);
}
