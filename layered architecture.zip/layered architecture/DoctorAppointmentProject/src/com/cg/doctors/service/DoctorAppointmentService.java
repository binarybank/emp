package com.cg.doctors.service;

import com.cg.doctors.bean.DoctorAppointment;
import com.cg.doctors.dao.DoctorAppointmentDao;
import com.cg.doctors.dao.IDoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	IDoctorAppointmentDao dao = new DoctorAppointmentDao();

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		int appointmentId = (int) (Math.random() * 100000);
		doctorAppointment.setAppointmentId(appointmentId);
		appointmentId = dao.addDoctorAppointmentDetails(doctorAppointment);
		return appointmentId;
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId) {
		DoctorAppointment doctorAppointment = dao.getAppointmentDetails(appointmentId);
		return doctorAppointment;
	}

}
