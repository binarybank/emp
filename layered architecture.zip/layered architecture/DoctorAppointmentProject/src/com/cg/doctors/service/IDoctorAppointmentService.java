package com.cg.doctors.service;

import com.cg.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentService {

	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment);

	DoctorAppointment getAppointmentDetails(int appointmentId);
}
