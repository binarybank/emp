package com.cg.doctors.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.doctors.bean.DoctorAppointment;
import com.cg.doctors.service.DoctorAppointmentService;
import com.cg.doctors.service.IDoctorAppointmentService;

public class Client {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		String pName;
		String problemName;
		DoctorAppointment doctorAppointment;
		IDoctorAppointmentService service = new DoctorAppointmentService();
		do {
			System.out.println("1 Book Doctor Appointment");
			System.out.println("2 View Doctor Appointment status");
			System.out.println("3 Exit");
			System.out.println("Enter your option");
			Scanner sc = new Scanner(System.in);
			int option = sc.nextInt();
			sc.nextLine();
			switch (option) {
			case 1:
				System.out.println("Enter the patient name :");
				pName = sc.nextLine();
				System.out.println("Enter the Problem Name :");
				problemName = sc.nextLine();
				doctorAppointment = new DoctorAppointment();
				doctorAppointment.setpName(pName);
				doctorAppointment.setProblemName(problemName);
				if (problemName.equalsIgnoreCase("Heart"))
					doctorAppointment.setDoctorName("HDoctor");
				else if (problemName.equalsIgnoreCase("ENT"))
					doctorAppointment.setDoctorName("EDoctor");
				else if (problemName.equalsIgnoreCase("Diabetes"))
					doctorAppointment.setDoctorName("DDoctor");
				else if (problemName.equalsIgnoreCase("gynecology"))
					doctorAppointment.setDoctorName("GDoctor");
				else if (problemName.equalsIgnoreCase("bone"))
					doctorAppointment.setDoctorName("BDoctor");
				else if (problemName.equalsIgnoreCase("dermatology"))
					doctorAppointment.setDoctorName("derDoctor");
				else
					doctorAppointment.setDoctorName(null);
				if (doctorAppointment.getDoctorName() != null)
					doctorAppointment.setAppointmentStatus("Approved");
				else
					doctorAppointment.setAppointmentStatus("DisApproved");
				doctorAppointment.setDate(LocalDate.now());
				int appointmentId = service.addDoctorAppointmentDetails(doctorAppointment);
				System.out.println("Your appointment id :" + appointmentId);
				break;
			case 2:
				System.out.println("enter your appointment id :");
				appointmentId = sc.nextInt();
				doctorAppointment = service.getAppointmentDetails(appointmentId);
				System.out.println("patient name: " + doctorAppointment.getpName());
				System.out.println("doctor name : " + doctorAppointment.getDoctorName());
				System.out.println("Appointment status : " + doctorAppointment.getAppointmentStatus());
				System.out.println("Appoint time booked : " + doctorAppointment.getDate());
				break;
			case 3:
				System.exit(0);
			}

		} while (true);
	}

}
