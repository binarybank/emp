package com.cg.bean;

import java.util.regex.Pattern;

public class ClassValidator {
	
	/************* To Validate the Id Field ***********/
	public boolean EmployeeId(int i) {

		String Pattern1 = "\\d{2}";
		String Pattern2 = String.valueOf(i);
		return Pattern.matches(Pattern1, Pattern2);
	}

	/************* To Validate the Name Field ***********/
	public boolean EmployeeName(String s) {

		String Pattern1 = "[a-zA-Z]+\\.?";
		String Pattern2 = String.valueOf(s);
		return Pattern.matches(Pattern1, Pattern2);
	}

	/************* To Validate the PanCard Number Field ***********/
	public boolean PanCardNumber(String p) {

		String Pattern1 = "^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$";
		String Pattern2 = String.valueOf(p);
		return Pattern.matches(Pattern1, Pattern2);
	}

	/************* To Validate the Salary Field ***********/
	public boolean Sal(double d) {

		String Pattern1 = "[0-9]+([,.][0-9]{1,2})?";
		String Pattern2 = String.valueOf(d);
		return Pattern.matches(Pattern1, Pattern2);
	}
}
