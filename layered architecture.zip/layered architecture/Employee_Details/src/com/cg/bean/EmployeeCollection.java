package com.cg.bean;

import java.util.ArrayList;
import java.util.Iterator;


public class EmployeeCollection {
	
	/************* Create a Static Block of Employee Details ***********/
	private static ArrayList<Employee> employeeList = null;
	static {
		employeeList = new ArrayList<Employee>();
		Employee b1 = new Employee(101, "Suresh", "ATGFH12345",33350);
		Employee b2 = new Employee(102, "Mahesh", "POKUH28843",150200);
		Employee b3 = new Employee(103, "Deepak", "ROPET56723",830000);
		Employee b4 = new Employee(104, "Pradeep", "QWVGT98561",1000350);
		Employee b5 = new Employee(105, "Ankita", "JUOLP761632",1950000);

		employeeList.add(b1);
		employeeList.add(b2);
		employeeList.add(b3);
		employeeList.add(b4);
		employeeList.add(b5);

	}

	public EmployeeCollection() {}

	/************* Add New Book in ArrayList ************/
	public void addNewEmployeeDetails(Employee pr) {
		employeeList.add(pr);
	}

	public static ArrayList<Employee> getEmployeeList() {
		return employeeList;
	}

	public static void setemployeeList(ArrayList<Employee> employeeList) {
		EmployeeCollection.employeeList = employeeList;
	}

	/************* Fetch All Employee Details ***********/

	public static void displayEmployeeCount() {
		Service s=new Service();
		s.Calculate();
		Iterator<Employee> employeeIt = employeeList.iterator();
		Employee tempemployee = null;

		int totalCount = 0;
		while (employeeIt.hasNext()) 
		{
			totalCount++;
			tempemployee = employeeIt.next();
			System.out.println(tempemployee);
		}
		System.out.println("Total Count " + totalCount);
	}

	
}
