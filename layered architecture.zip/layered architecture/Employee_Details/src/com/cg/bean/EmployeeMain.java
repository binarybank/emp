package com.cg.bean;

import java.util.Scanner;

public class EmployeeMain {

	static EmployeeCollection collectionhelper = null;

	static Employee e;

	public static void main(String[] args) {

		boolean i = true;
		int opt = 0;
		Service s = new Service();
		
		
		/************* Display the User Interface ***********/
		System.out.println("Welcome to Employee IncomeTax System");
		System.out.println("-------------------------------------");
		
		Scanner scr = new Scanner(System.in);
		
		while (i) {
			System.out.println("1.Enter Employee details");
			System.out.println("2.Calculate IncomeTax and Display Details");
			System.out.println("3.Exit System");
			opt = scr.nextInt();
			switch (opt) {
			case 1: {
				s.getEmployeeDetails();
				break;
			}
			case 2: {

				collectionhelper.displayEmployeeCount();
				break;
			}
			case 3: {
				i = false;
				System.exit(0);
				break;
			}
			default: {
				System.out.println("Wrong input\n");
			}
			}
		}
	}

}
