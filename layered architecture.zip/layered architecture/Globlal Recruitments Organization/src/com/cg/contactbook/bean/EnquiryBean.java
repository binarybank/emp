package com.cg.contactbook.bean;

public class EnquiryBean {

	public EnquiryBean() {

	}
	
	private int enqryid;
	private String fname;
	private String lName;
	private String contactNo;
	private String pLocation;
	private String pDomain;
	
	
	public EnquiryBean( String fname, String lName,
			String contactNo, String pLocation, String pDomain) {
		super();
		//this.enqryid = enqryid;
		this.fname = fname;
		this.lName = lName;
		this.contactNo = contactNo;
		this.pLocation = pLocation;
		this.pDomain = pDomain;
	}


	public int getEnqryid() {
		return enqryid;
	}


	public void setEnqryid(int enqryid) {
		this.enqryid = enqryid;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}


	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getpLocation() {
		return pLocation;
	}


	public void setpLocation(String pLocation) {
		this.pLocation = pLocation;
	}


	public String getpDomain() {
		return pDomain;
	}


	public void setpDomain(String pDomain) {
		this.pDomain = pDomain;
	}


	@Override
	public String toString() {
		return "EnquiryBean [enqryid=" + enqryid + ", fname=" + fname
				+ ", lName=" + lName + ", contactNo=" + contactNo
				+ ", pLocation=" + pLocation + ", pDomain=" + pDomain + "]";
	}
	
	
	

}
