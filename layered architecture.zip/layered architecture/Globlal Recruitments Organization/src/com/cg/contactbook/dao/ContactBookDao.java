package com.cg.contactbook.dao;

import java.util.List;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookexception;

public interface ContactBookDao {

	public int addEnquiry(EnquiryBean enqry) throws ContactBookexception;

	public List<EnquiryBean> getEnquiryDetails()throws ContactBookexception;

	public EnquiryBean getDetails(int id)throws ContactBookexception;

	

}
