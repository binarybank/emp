package com.cg.contacbook.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;


import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookexception;



public class ValidateContactBookDaoTest {
	static EnquiryBean eb;
	static ContactBookDao dao;
	static ContactBookDaoImpl Dao;

	@BeforeClass
	public static void init(){
	 Dao=new ContactBookDaoImpl();
	dao=new ContactBookDaoImpl();
	eb =new EnquiryBean();	
	}
	@Test
	public void addEnquiry()throws ContactBookexception{
		assertNotNull(dao.addEnquiry(eb));
		
	}
	
	@Test
	
	public void testAddDonarDetails2() throws ContactBookexception {

		eb.setFname("Sankar");
		eb.setlName("Gupta");
		eb.setContactNo("8179178101");
		eb.setpLocation("Banglore");
		eb.setpDomain("Java");
		assertTrue("Data Inserted successfully",
				(dao.addEnquiry(eb)) > 1000);

	}
	
	@Test
	public void testViewAll() throws ContactBookexception {
		assertNotNull(dao.getDetails(1001));
	} 

}
