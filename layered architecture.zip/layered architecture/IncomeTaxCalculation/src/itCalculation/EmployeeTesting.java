package itCalculation;

import junit.framework.Assert;

import org.junit.Test;

public class EmployeeTesting {


	EmployeeValidation valid = new EmployeeValidation();
	boolean result;
	
	@Test
	public void test_validatePan() throws EmployeeException
	{
		result = EmployeeValidation.isValidatePan("GGHYI87658");
		Assert.assertEquals(true, result);
	}
	
	
	@Test
	public void test_validatePan1()throws EmployeeException
	{
		result = EmployeeValidation.isValidatePan("nsjsj87658"); // using small letters in pan no.
		Assert.assertEquals(false, result);
	}
	
	@Test
	public void test_validatePan2()throws EmployeeException 
	{
		result = EmployeeValidation.isValidatePan(" "); //Leaving the pan details NUll
		Assert.assertEquals(false, result);
	}
	
	@Test
	public void test_validatePan3()throws EmployeeException
	{
		result = EmployeeValidation.isValidatePan("HG676%%^78"); // using symbols in pan no.
		Assert.assertEquals(false, result);
	}

	@Test
	public void test_validateSalary()throws EmployeeException
	{
		result = EmployeeValidation.isValidateSalary("55000.00");
		Assert.assertEquals(true, result);
	}
	
	@Test
	public void test_validateSalary1()throws EmployeeException
	{
		result = EmployeeValidation.isValidateSalary("55000"); // not entering the decimal values
		Assert.assertEquals(false, result);
	}
	
	@Test
	public void test_validateSalary2()throws EmployeeException
	{
		result = EmployeeValidation.isValidateSalary(" "); // Leaving the field blank
		Assert.assertEquals(false, result);
	}
	
	@Test
	public void test_validateSalary3()throws EmployeeException
	{
		result = EmployeeValidation.isValidateSalary("jhsdjh"); // Entering characters in the field
		Assert.assertEquals(false, result);
	}
	
}
