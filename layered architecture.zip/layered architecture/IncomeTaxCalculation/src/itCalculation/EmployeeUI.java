package itCalculation;

import java.util.Scanner;


public class EmployeeUI {

	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args)
	{
		int ch=0;

		while(true)
		{
			System.out.println("\n Enter your choice : \n 1. Enter Employee details \n"
					+ " 2. Compute Income Tax amount and display the details \n "
					+ "3. Exit. ");
			
			ch = sc.nextInt();
			switch(ch)
			{
			case 1 : enterDetails(); 
					 break;
			
			case 2 : EmployeeCollection.calculate();
					 break;
			
			case 3 : System.exit(0);
			
			}
			
			}	
	}
	
	/**********************Enter Employee Details**************************/
	public static void enterDetails()
	{
		
		try 
		{
			System.out.println("\n Enter EmpId \t");
			String id = sc.next();
			System.out.println("\n Enter Employee Name : \t");
			String name = sc.next();
			System.out.println("\n Enter Pan Card No. : \t");
			String pan = sc.next();
			if(EmployeeValidation.isValidatePan(pan))
			{
				System.out.println("\n Enter Annual Salary : \t");
				String sal = sc.next();
				if(EmployeeValidation.isValidateSalary(sal))
				{
						EmployeeDetails e = new EmployeeDetails(Integer.parseInt(id),name, pan, Double.parseDouble(sal));
						EmployeeCollection.addEmployeeDetails(e);
					}
				}
		
		}
		catch (EmployeeException e)
		{			
			System.out.println(e.getMessage());
		}
	}
}


