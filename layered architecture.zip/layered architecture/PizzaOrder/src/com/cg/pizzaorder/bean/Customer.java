package com.cg.pizzaorder.bean;

public class Customer {
private int customerid;
private String custname;
private String address;
private String phone;
public int getCustomerid() {
	return customerid;
}
public void setCustomerid(int customerid) {
	this.customerid = customerid;
}
public String getCustname() {
	return custname;
}
public void setCustname(String custname) {
	this.custname = custname;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
@Override
public String toString() {
	return "Customer [customerid=" + customerid + ", custname=" + custname + ", address=" + address + ", phone=" + phone
			+ "]";
}

}
