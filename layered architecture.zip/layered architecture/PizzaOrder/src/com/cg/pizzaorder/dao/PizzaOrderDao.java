package com.cg.pizzaorder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.util.DatabaseConnection;

public class PizzaOrderDao implements IpizzaOrderDao {

	private Connection con;

	public PizzaOrderDao() {
		con = DatabaseConnection.getConnection();
	}

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		int orderid = generateOrderId();// (int) (Math.random() * 1000);
		int customerid = generateCustomerId();// (int) (Math.random() * 1000);
		customer.setCustomerid(customerid);
		pizza.setOrderid(orderid);
		pizza.setCustomerid(customerid);
		String sql = "insert into customer2 values(?,?,?,?)";
		// create table customer2(customerid number primary key,custname varchar2(20),
		// address varchar2(20), phone varchar2(20));
		PreparedStatement statement;
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, customerid);
			statement.setString(2, customer.getCustname());
			statement.setString(3, customer.getAddress());
			statement.setString(4, customer.getPhone());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		sql = "insert into pizzaorder values(?,?,?)";
		// create table pizzaorder(orderid number, customerid number references
		// customer2,totalprice number);
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, orderid);
			statement.setInt(2, pizza.getCustomerid());
			statement.setDouble(3, pizza.getTotalprice());
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pizza.getOrderid();
	}

	private int generateCustomerId() {
		String sql = "select customerid.nextval from dual";
		// create sequence customerid start with 1 increment by 1;
		int customerid = 0;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next())
				customerid = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return customerid;
	}

	private int generateOrderId() {
		String sql = "select orderid.nextval from dual";
		// create sequence orderid start with 1 increment by 1;
		int orderid = 0;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			if (rs.next())
				orderid = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return orderid;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		String sql = "select * from pizzaorder where orderid=?";
		PizzaOrder order = null;
		try {
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setInt(1, orderid);
			ResultSet set = statement.executeQuery();
			while(set.next()) {
				 order = new PizzaOrder();
				order.setOrderid(set.getInt(1));
				order.setCustomerid(set.getInt(2));
				order.setTotalprice(set.getDouble(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return order;
	}

}
