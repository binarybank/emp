package com.cg.pizzaorder.exception;

public class PizzaException extends Exception {
	

public PizzaException(String s) {
	System.out.println(s);
}
}