package com.cg.pizzaorder.service;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

public class CustomerValidator {
	public static boolean validatePhone(String phone) {
		if (Pattern.matches("[7-9][0-9]{9}", phone)) {
			return true;
		} else
			return false;
	}

	public boolean validateName(String name) {
		Pattern pat = Pattern.compile("^[A-Z][a-z]{4,15}$");
		Matcher mat = pat.matcher(name);
		if (mat.matches())
			return true;
		else
			return false;
	}

}
