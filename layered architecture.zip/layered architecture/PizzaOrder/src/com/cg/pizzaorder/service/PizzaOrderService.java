package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDao;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {

	PizzaOrderDao dao = new PizzaOrderDao();

	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		PizzaOrder pizzaOrder = dao.getOrderDetails(orderid);
		return pizzaOrder;
	}

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		int orderid = dao.placeOrder(customer, pizza);
		return orderid;
	}

}
