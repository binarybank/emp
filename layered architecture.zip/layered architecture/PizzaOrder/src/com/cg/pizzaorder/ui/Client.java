package com.cg.pizzaorder.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.CustomerValidator;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {

	public static void main(String[] args) throws PizzaException {
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("1.Place order");
			System.out.println("2.Display order");
			System.out.println("3.Exit");
			int option = sc.nextInt();
			sc.nextLine();
			switch (option) {
			case 1:
				System.out.println("Enter the name of customer");
				String custname = sc.nextLine();
				System.out.println("Enter customer address");
				String address = sc.nextLine();
				System.out.println("Enter customer phNo");
				String phone = sc.nextLine();
				if (CustomerValidator.validatePhone(phone) == false) {
					System.err.println("Enter valid phone number");
					break;
				}
				System.out.println("Type of pizza topping preferred");
				System.out.println("1.Capsicum 2.Mushroom 3.Jalapeno 4.Paneer ");
				int top = sc.nextInt();
				double price = 350;
				if (top == 1) {
					price += 30;
				} else if (top == 2) {
					price += 50;
				} else if (top == 3) {
					price += 70;

				} else if (top == 4) {
					price += 85;
				} else {
					System.out.println("Enter correct toppings");
					break;
				}
				System.out.println("Order date:" + LocalDate.now());
				Customer customer = new Customer();
				customer.setAddress(address);
				customer.setPhone(phone);
				customer.setCustname(custname);
				PizzaOrder pizza = new PizzaOrder();
				pizza.setTotalprice(price);
				IPizzaOrderService service = new PizzaOrderService();
				int orderid = service.placeOrder(customer, pizza);
				System.out.println("your order is " + orderid);
				break;
			case 2:
				System.out.println("Enter the orderid");
				orderid = sc.nextInt();
				sc.nextLine();
				service = new PizzaOrderService();
				pizza = service.getOrderDetails(orderid);
				System.out.println(pizza);
				break;
			case 3:
				System.exit(0);
			default:
				System.out.println("Enter correct choice");
			}
		} while (true);

	}
}