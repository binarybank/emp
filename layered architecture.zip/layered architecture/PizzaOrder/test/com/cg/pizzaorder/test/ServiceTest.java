package com.cg.pizzaorder.test;

import org.junit.Test;

import com.cg.pizzaorder.service.CustomerValidator;

import junit.framework.Assert;

public class ServiceTest {

	@Test
	public void test() {
		CustomerValidator validator = new CustomerValidator();
		boolean actual = validator.validateName("Rajesh");
		boolean expected = true;
		Assert.assertEquals(expected, actual);
	}
	@Test
	public void test1() {
		boolean actual = CustomerValidator.validatePhone("9874563210");
		boolean expected = true;
		Assert.assertEquals(expected, actual);
	}
}
