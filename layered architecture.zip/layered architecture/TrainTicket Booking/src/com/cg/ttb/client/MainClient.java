package com.cg.ttb.client;

import java.util.List;
import java.util.Scanner;

import com.cg.ttb.beans.BookingBean;
import com.cg.ttb.beans.TrainBean;
import com.cg.ttb.exception.TrainException;
import com.cg.ttb.service.ITrainService;
import com.cg.ttb.service.TrainServiceImpl;

public class MainClient {

	public static void main(String[] args) {
		ITrainService service = new TrainServiceImpl();
		Scanner scanner = new Scanner(System.in);
		System.out.println("******Menu********");
		do {
			System.out.println("1.Book Ticket");
			System.out.println("2.Exit");
			System.out.println("Please Enter Your Choice");
			String choice = scanner.next();
			switch (choice) {
			case "1":

				try {
					List<TrainBean> tlist = service.retrieveTrainDetails();
					if (tlist.size() == 0) {
						System.err.println("No trains available\n");
					} else {
						for (TrainBean t : tlist) {
							System.out.println(t);
						}
					}
				} catch (TrainException e) {
					System.err
							.println("Unable to show list\n" + e.getMessage());
				}
				System.out.println("Please Enter Customer Id:");
				String custId = scanner.next();
				System.out.println("Please Enter Train Id:");
				int trainId = scanner.nextInt();
				System.out.println("Please Enter Number of Seats");
				int noOfSeat = scanner.nextInt();
				BookingBean bookingbean = new BookingBean(noOfSeat, trainId,
						custId);
				try {
					int bookingid = service.bookTicket(bookingbean);
					System.out.println("your Booking Id is:"+bookingid+" "+"trainId:"+trainId+" "+"customerId:"+" "+custId+"no of seats Booked:"+noOfSeat+" ");
				} catch (TrainException e) {
					System.out.println(e.getMessage());
				}

				break;

			case "2":

				break;

			default:
				System.out.println("Please Enter Correct Input");
				break;
			}
		} while (true);

	}

}
