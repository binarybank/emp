package com.cg.ttb.service;

import java.util.List;

import com.cg.ttb.beans.BookingBean;
import com.cg.ttb.beans.TrainBean;
import com.cg.ttb.exception.TrainException;

public interface ITrainService {

	public List<TrainBean> retrieveTrainDetails() throws TrainException;

	public int bookTicket(BookingBean bookingbean) throws TrainException;

}
