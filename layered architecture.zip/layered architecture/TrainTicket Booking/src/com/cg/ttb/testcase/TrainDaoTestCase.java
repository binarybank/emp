package com.cg.ttb.testcase;



import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ttb.beans.BookingBean;
import com.cg.ttb.dao.TrainDaoImpl;
import com.cg.ttb.exception.TrainException;

public class TrainDaoTestCase {

	static  TrainDaoImpl tdaoimpl;
	static BookingBean bookingbean;
	
	@BeforeClass
	public static void intialize() throws TrainException{
		
		tdaoimpl=new TrainDaoImpl();
		bookingbean = new BookingBean();
	}
	
	@Test 
	public  void testBookTicket() throws TrainException{
		bookingbean.setBookingId(3000);
		bookingbean.setCustId("1254");
		bookingbean.setNoOfSeat(3);
		bookingbean.setTrainId(1);
		assertNotNull("Booked", tdaoimpl.bookTicket(bookingbean)>1000);
	}
	
	@Test
	public void testBookId() throws TrainException{
		
		int tid=tdaoimpl.generateBookingId();
		assertEquals("Test Correct",tid+1,tdaoimpl.generateBookingId());
	}
	@Test
	public void  testTrainDetails() throws TrainException{
		
		assertNotNull(tdaoimpl.retrieveTrainDetails());
	}
	

}
