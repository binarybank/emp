package com.capgemini.dao;

import java.util.List;

import com.capgemini.beans.BookingBean;
import com.capgemini.beans.TrainBean;
import com.capgemini.exception.TrainException;

public interface TrainDao {

	List<TrainBean> retrieveTrainDetails() throws TrainException;

	int bookTicket(BookingBean bookingbean) throws TrainException;

	int generateBookingId()  throws TrainException;

}
