package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.beans.BookingBean;
import com.capgemini.beans.TrainBean;
import com.capgemini.exception.TrainException;
import com.capgemini.util.DBUtil;

public class TrainDaoImpl implements TrainDao {
	Connection conn = null;

	@Override
	public List<TrainBean> retrieveTrainDetails() throws TrainException {
		List<TrainBean> trainList = new ArrayList<TrainBean>();
		conn = DBUtil.getConnection();
		Statement stmt;
		try {
			stmt = conn.createStatement();
			ResultSet rst = stmt
					.executeQuery(QueryMapper.RETRIVE_ALL_TRAINDETAILS_QUERY);
			while (rst.next()) {
				TrainBean trainbean = new TrainBean();
				// String trainId=null;
				trainbean.setTrainId(rst.getInt(1));
				trainbean.setTrainType(rst.getString(2));
				trainbean.setFromStop(rst.getString(3));
				trainbean.setToStop(rst.getString(4));
				trainbean.setFare(rst.getInt(5));
				trainbean.setAvailableSeats(rst.getInt(6));
				trainbean.setDateOfJourney(rst.getDate(7));
				// Date dateOfJourney = Date.valueOf(LocalDate.now());
				trainList.add(trainbean);
			}

		} catch (SQLException e) {
			throw new TrainException("Prolem in Fetching TrainDetail list");
		}
		return trainList;
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws TrainException {
		bookingbean.setBookingId(generateBookingId());
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn
					.prepareStatement(QueryMapper.INSERT_ALL_BOOKING_DETAILS_QUERY);
			pst.setInt(1, bookingbean.getBookingId());
			pst.setString(2, bookingbean.getCustId());
			pst.setInt(3, bookingbean.getTrainId());
			pst.setInt(4, bookingbean.getNoOfSeat());
			int update = pst.executeUpdate();
			if (update == 1) {
				String sql1 = "select availableseats from traindetails where trainid=?";
				PreparedStatement statement2 = conn.prepareStatement(sql1);
				statement2.setInt(1, bookingbean.getTrainId());
				ResultSet set = statement2.executeQuery();
				int availableseats = 0;
				while (set.next()) {
					availableseats = set.getInt(1);
				}
				String sql = "Update traindetails set availableseats=? where trainid=?";
				PreparedStatement statement = conn.prepareStatement(sql);
				statement.setInt(1, availableseats - bookingbean.getNoOfSeat());
				statement.setInt(2, bookingbean.getTrainId());
				statement.executeUpdate();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return bookingbean.getBookingId();
	}

	public int generateBookingId() throws TrainException {
		int bid = 0;
		try {
			conn = DBUtil.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rst;
			rst = stmt.executeQuery(QueryMapper.GENERATE_BOOKINGID_QUERY);
			while (rst.next()) {
				bid = rst.getInt(1);
			}
		} catch (SQLException e) {
			throw new TrainException("Problem in generating Booking id");
		}
		return bid;

	}

}