package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.BookingBean;
import com.capgemini.beans.TrainBean;
import com.capgemini.exception.TrainException;

public interface TrainService {

	public List<TrainBean> retrieveTrainDetails() throws TrainException;

	public int bookTicket(BookingBean bookingbean) throws TrainException;

}
