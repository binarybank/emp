package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.BookingBean;
import com.capgemini.beans.TrainBean;
import com.capgemini.dao.TrainDao;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.exception.TrainException;

public class TrainServiceImpl implements TrainService {
	TrainDao dao = new TrainDaoImpl();

	@Override
	public List<TrainBean> retrieveTrainDetails() throws TrainException {
		
		return dao.retrieveTrainDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws TrainException {
		// TODO Auto-generated method stub
	return dao.bookTicket(bookingbean);
	}

}
